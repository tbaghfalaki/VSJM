n=500
m=10
t<-c(0,2,4,6,8,10,12,14,16,18)
sigma=1
D=diag(.5,2)+matrix(.5,2,2)
b=mnormt::rmnorm(n,c(0,0),D)
B=c(3,2,1,1)
x1=rnorm(n)
x2=c(rep(0,n/2),rep(1,n/2))
x3=rnorm(n,1,.5)
mu=matrix(0,n,m)

  for(i in 1:n){
    for(j in 1:m){
      mu[i,j]=2+B[1]*x1[i]+B[2]*x2[i]+B[3]*x3[i]+B[4]*t[j]+b[i,1]+b[i,2]*t[j]
    }}

  Y=matrix(0,n,m)
  for(i in 1:n){
    for(j in 1:m){
      Y[i,j]=rnorm(1,mu[i,j],sigma)
    }}
  alpha1=c(-3,2,1)
  r=2;gamma=c(1,-1)
  surt=c()
  for (i in 1:n){
    mu1<-alpha1[1]+alpha1[2]* x1[i]+ alpha1[3]*x2[i]+gamma[1]*b[i,1]+gamma[2]*b[i,2]
    surt[i]<-rweibull(1,r,exp(-mu1/r))
  }

  for (i in 1:n){
    if ((surt[i]>0) & (surt[i]<2) )(Y[i,2:10]=NA)
    if ((surt[i]>2) & (surt[i]<4) )(Y[i,3:10]=NA)
    if ((surt[i]>4) & (surt[i]<6) )(Y[i,4:10]=NA)
    if ((surt[i]>6) & (surt[i]<8) )(Y[i,5:10]=NA)
    if ((surt[i]>8) & (surt[i]<10) )(Y[i,6:10]=NA)
    if ((surt[i]>10) & (surt[i]<12) )(Y[i,7:10]=NA)
    if ((surt[i]>12) & (surt[i]<14) )(Y[i,8:10]=NA)
    if ((surt[i]>14) & (surt[i]<16) )(Y[i,9:5]=NA)
    if ((surt[i]>16) & (surt[i]<18) )(Y[i,10]=NA)
  }
q<-quantile(surt, 0.9)
event=rep(0,n)
event[surt>q]=1
surt[surt>q]=q

  xn=matrix(rbinom(n*10,1,.5),n,10)
  x=cbind(1,x1,x2,x3,xn)
  p1=dim(x)[2]
  w=cbind(1,x1,x2,xn[,1:5])
  p2=dim(w)[2]
  time=matrix(rep(t,n),n,byrow=TRUE)

  Res=CS(Y=Y, time=time, x=x, w=w, surt=surt, event=event,
              niter=1000, nburnin=500, nthin=2, nchains=2)
  print(Res)
